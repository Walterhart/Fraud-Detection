from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

lineSpacing = 100

def printStatement(lineSpacing):
       ##To be outputted
       line1 = "~ Welcome to ~"
       line2 = "ROBINDABANK"
       line3 = "A fraud detecting software"
       line4 = "Version: " + row[0]
       
       #format to make it look nice
       line1 = line1.center(lineSpacing, ' ')
       line2 = line2.center(lineSpacing, ' ')
       line3 = line3.center(lineSpacing, ' ')
       line4 = line4.center(lineSpacing, ' ')

       print()
       print(line1)
       print(line2)
       print(line3)
       print(line4)
       print()
       print()
       nextLine = "Press enter to continue"
       nextLIne = nextLine.center(lineSpacing, ' ')
       input(nextLine)
       print()
       return()

#Menu
printStatement(lineSpacing)

user = ""
while not(user == "Y" or user == "y" or user == "N" or user == "n"):
    print("Are you an admin? Y for yes N for no")
    user = input();

    if user == "Y" or user == "y":
        ##direct to page
        execfile('machineLearning.py')
    elif user == "N" or user == "n":
        ##direct to page
        execfile('userPage.py')
    else:
        print("Try again, format incorrect")