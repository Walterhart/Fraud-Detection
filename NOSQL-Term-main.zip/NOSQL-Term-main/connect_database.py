from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

#Make sure to download bundle and setpath
cloud_config= {
        'secure_connect_bundle': 'C:\\Users\\walte\\Downloads\\secure-connect-robbindaBank.zip'
}
auth_provider = PlainTextAuthProvider('RwdDdyDkMflEYDdORlZuUgjj', 'WBwSZAN5Yr-JXXxr,mfjWdYwn,tE2yn+Zs5Z9LosKKG5duLbvTwBpP2XEgtl3wJWeg2lsNu.TgqctybuaaW9eNFe6W.CjpDh8uZaT+LWLx95LLctKpYhwGdJioZXj86e')
cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
session = cluster.connect()

row = session.execute("select release_version from system.local").one()
if row:
    print(row[0])
else:
    print("An error occurred.")

