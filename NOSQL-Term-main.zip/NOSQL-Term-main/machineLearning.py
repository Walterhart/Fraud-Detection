from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

import pandas as pd
import numpy as np
import seaborn as sns 
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import math
from sklearn import svm
from pandas.plotting import scatter_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from sklearn.linear_model import LogisticRegression

mlData = session.execute("SELECT * FROM  robbinda_space.data_table;")
print (mlData)

#change hours from after 9pm to flag it and before 6am? doesnt matter the day... look at when the time is standardized on time zone
#compare the zipcode of every person??
#need location!@ get latt and long and find formula for what is too large... 200miles?
# look at person, find teh distances between all purchses, find largest, adn if larger than 200 mark as frauds
#flag amounts larger than 500? -->larger than 320 km
#how fast in between transaction
### Look at categories, common for each person and if out of no where flag

###credit to https://www.movable-type.co.uk/scripts/latlong.html
def distance (homeLat, homeLong, merchLat, merchLong):
    homeLat = float(homeLat)
    homeLong = float(homeLong)
    merchLat = float(merchLat)
    merchLong = float(merchLong)

    R = 6371e3
    phi1 = homeLat * math.pi/180
    phi2 = merchLat * math.pi /180
    deltaPhi = (merchLat - homeLat) * math.pi/180
    deltaLambda = (merchLong - homeLong) * math.pi/180

    a = math.sin(deltaPhi/2) * math.sin(deltaPhi/2) + math.cos(phi1) * math.cos(phi2) * math.sin(deltaLambda/2) * math.sin(deltaLambda/2)
    c = 2 * math.atan(math.sqrt(a))

    return R * c


ifDist = []
for x in range(len(homeLat)):
    length = distance(homeLat[x], homeLong[x], merchLat[x], merchLong[x])
    ifDist.append(length)

hour = 0
ifBedTime = []
for col in time:
    hour = col[11:13]
    hour = float(hour)
    ifBedTime.append(hour)

#the data
X = np.array([amt, ifBedTime, ifDist])
y = np.array(fraud)

X = X.transpose()

X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=1)

#rebalance the data
sm = SMOTE(random_state = 1)
X_train, y_train = sm.fit_resample(X_train, y_train.ravel())

##SUPPORT VECTOR MACHINE
#clf = svm.SVC(kernel = 'linear', C=1.0)
#clf.fit(X_train, y_train.ravel())
#predict = clf.predict(X_test)
#cf_matrix = confusion_matrix(y_test,predict)

#print("SVM")
#print(cf_matrix)
#print(clf.score(X_test, y_test))

##LOGISTIC REGRESSION
lr = LogisticRegression(solver = 'liblinear', random_state = 1)
lr.fit(X_train, y_train.ravel())

print("Logistic Regression")
print(lr.score(X_test, y_test))
predict = lr.predict(X_test)






###FOR ADMIN
#Make sure to download bundle and setpath
cloud_config= {
    'secure_connect_bundle': 'C:\\Users\\burge\\Downloads\\secure-connect-robbinda-bank.zip'
}
auth_provider = PlainTextAuthProvider('RwdDdyDkMflEYDdORlZuUgjj', 'WBwSZAN5Yr-JXXxr,mfjWdYwn,tE2yn+Zs5Z9LosKKG5duLbvTwBpP2XEgtl3wJWeg2lsNu.TgqctybuaaW9eNFe6W.CjpDh8uZaT+LWLx95LLctKpYhwGdJioZXj86e')
cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
session = cluster.connect()

row = session.execute("select release_version from system.local").one()
if row:
    #login
    print("Please provide the admin password: ")
    password = input()

    if(password == "RobbingTheVault"):
        login = "  Login Accepted  "
        login = login.center(lineSpacing, '=')
        print(login)
        print()
    else:
        while not (password == "exit" or password == "RobbingTheVault"):
            print("Try again")
            print("Please type in the password again OR type in exit to quit")
            password = input()

    if(password == "exit" or password == "Exit"):
        quit()
    else:
       print("Welcome " + name)
       input()
       print("Please choose what you would like to do today:")
       option1 = "1. Insert Records"
       option1 = option1.center(lineSpacing, ' ')
       option2 = "2. Check For Fraud" 
       option2 = option2.center(lineSpacing, ' ')
       print(option1)
       print(option2)
       choice = input('Choose a numbered option: ')
    
       while (choice != 1 or choice != 2):
           print("Please try again")
           choice = input('Choose a numbered option: ')
          
       print()
    
       #Train the data here to be ready
       mlData = session.execute("SELECT * FROM  robbinda_space.data_table;")
       mlData = list(mlData)
    
       newData = []
    
       if choice == 1: ###Insert data
           chosen = "You have chosen to: Insert Records"
           chosen = chosen.center(lineSpacing, ' ')
           print("=" * lineSpacing)
           print(chosen)
           print()

           print("Please provide the file location containing the records to be added:")
           location = input('File location: ')
    
           dash = "\\"
           #Gets the format into something python can check on
           newLocation = location.replace("\", dash) 

           #Need to check if the file location is valid here


           #Beneath is copy and pasted from machineLearning.py
           fields = []
           rows = []

           #This will open and read in the file data
           with open(filename, 'r') as csvfile:
           csvreader = csv.reader(csvfile)

           fields = next(csvreader)

           for row in csvreader:
               rows.append(row)


           ###Format the data! Pick to find the important data

           #Need col 1, 5, 11, 12, 15, 16, 17, 20
           time = [] #col1
           amt = [] #col5
           homeLat = [] #col11
           homeLong = [] #col12
           merchLat = [] #col15
           merchLong = [] #col16
           fraud = [] #col17
           name = [] #col20

           #picks through to find relevant information
           for row in rows:
              time.append(row[0])
              amt.append(row[4])
              homeLat.append(row[10])
              homeLong.append(row[11])
              merchLat.append(row[14])
              merchLong.append(row[15])
              fraud.append(row[16])
              name.append(row[19])

            #insert the rows into cassandra here
            #make sure all the new data is added to newData

       elif choice == 2: ###Machine Learning
           chosen = "You have chosen to: Check For Fraud"
           chosen = chosen.center(lineSpacing, ' ')
           print("=" * lineSpacing)
           print(chosen)
           print()

           if not newData:
               print("Everything is up to date, no need to check for fraud")

           else:
               #Clear out the data for next time
               newData = []