import csv

from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

### FOR AN AVERAGE JOE
cloud_config= {
        'secure_connect_bundle': 'C:\\Users\\burge\\Downloads\\secure-connect-robbinda-bank.zip'
}
auth_provider = PlainTextAuthProvider('uSAvdzgPhfMAXbZFYNZDaRWw', '+_SP-NSSfJtzX-hI2ZOPatvF9_4t-ms.Z1ImrXK3.f+gYOOrRKBj5qwyiEODyXPodPe3fvKgyhEY6.fqG37zf0So4QemXz4nOY2mLZSd+zcZ9cnU4jbMnLx8a08d.aJj')
cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
session = cluster.connect()

row = session.execute("select release_version from system.local").one()
if row:
    #login
    print("Please log in to your account: ")
    # tables: user_profile,  user_credential
    #credential check
    email ='DavidLewis22@email.com'        #input('Email:')
    password ='DLewis@14'  #input('Password:')
    #DavidLewis22@email.com  DLewis@14 
    #stores row info
    credential=session.execute("SELECT * FROM robbinda_space.user_credentials WHERE user_email= '%s' AND user_password= '%s';" % (email, password))
    credential = list(credential)
    
    while not credential:
        print ("Does not exist")
        print("Please try again")
        email = input('Email: ')
        password = input('Password:')
        credential=session.execute("SELECT * FROM robbinda_space.user_credentials WHERE user_email= '%s' AND user_password= '%s';" % (email, password))
        credential = list(credential)
 
    login = "  Login Accepted  "
    login = login.center(lineSpacing, '=')
    print(login)
    print()

    #Get profile details
    id=credential[0].new_id
    profile=session.execute("SELECT * FROM robbinda_space.user_profile_table WHERE new_id= %d ;" % (id))
    profile = list(profile)

    welcomeMessage= "Hello " + profile[0].first
    welcomeMessage = welcomeMessage.center(lineSpacing, ' ')
    print(welcomeMessage)
    input()

    print("Profile Page Details: ")
    profile_details= "  Name: %s %s\n  Credit Card: %s\n  Email: %s\n  Address: %s, %s, %s, %s\n  Gender: %s\n  Job: %s" %(profile[0].first, profile[0].last, profile[0].cc_num, profile[0].user_email, profile[0].street, profile[0].city, profile[0].state, profile[0].zip, profile[0].gender, profile[0].job)
    print(profile_details)

    #purchase history
    purchase_history= session.execute("SELECT * FROM robbinda_space.data_table  WHERE new_id= %d ;" % (id))
    purchase_history = list(purchase_history)
   
    prevMonth = 1
    for i in range(len(purchase_history)):
        #format date to be outputted
        timeDate = str(purchase_history[i].trans_date_trans_time)
        timeDate = timeDate.split()
        date = timeDate[0]
        time = timeDate[1]

        date = date.split('-')
        year = date[0]
        month = date[1]
        day = date[2]

        merchant = str(purchase_history[i].merchant)
        merchant = merchant.replace('_', ' ')

        money = str(purchase_history[i].amt)

        category = str(purchase_history[i].category)
        category = category.replace('_', ' ')

        ifFraud = purchase_history[i].is_fraud
  
        if(prevMonth != month):
            #restart and format
            prevMonth = month

            input()
            inbetween = "  Month: " + month + "  "
            inbetween = inbetween.center(lineSpacing, "=")
            print(inbetween)
            print("Date:       Time:        Category:           Merchant:                     Money:  Fraud:")
            print(month + "/" + day + "/" + year + "  " + time + "     " + "{:<20}".format(category) + "{:<30}".format(merchant) + "$" + "{:<7}".format(money) + ifFraud)
        else:
            print(month + "/" + day + "/" + year + "  " + time + "     " + "{:<20}".format(category) + "{:<30}".format(merchant) + "$" + "{:<7}".format(money) + ifFraud) 

else:
    print("An error occurred.")